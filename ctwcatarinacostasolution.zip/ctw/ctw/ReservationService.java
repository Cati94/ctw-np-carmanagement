import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import static java.time.temporal.ChronoUnit.*;

public class ReservationService {

    // Reservation hours
    private static final int START_HOUR = 8;
    private static final int END_HOUR = 20;
    private static final int BUFFER_HOUR_BEFORE = 7; // 1 hour before the start time (07:00)
    private static final int BUFFER_HOUR_AFTER = 21; // 1 hour after the end time (21:00)

    public static boolean isReservationValid(LocalDateTime dateTimeReserve, LocalDateTime dateTimeDrop) {
        boolean result = false;
        // Check if both reservation and drop-off dates are between Monday and Friday
        if (!isWeekday(dateTimeReserve)) {
            System.out.println("Reservation can only be made Monday to Friday.");
        } else if (!isWeekday(dateTimeDrop)) {
            System.out.println("Reservation can only be made Monday to Friday.");
        } else if (!isWithinAllowedHours(dateTimeReserve) || !isWithinAllowedHours(dateTimeDrop)) {
            System.out.println("Reservation can only be made between 08:00 and 20:00.");
        } else if (isInRestrictedBufferZone(dateTimeReserve) || isInRestrictedBufferZone(dateTimeDrop)) {
            System.out.println("Cannot reserve or drop off within 1 hour before or after allowed times.");
        } else {// Check if the reservation is within 4 days (96 hours)
            long hoursBetween = HOURS.between(dateTimeReserve, dateTimeDrop);
            if (hoursBetween > 96) {
                System.out.println("Reservation cannot be longer than 4 days.");
            } else {
                System.out.println("Reservation is valid.");
                result = true;
            }
        }

        return result;
    }

    // Save the reservation in the database
    public static void saveReservation(int carId, int clientId, LocalDateTime dateTimeReserve, LocalDateTime dateTimeDrop, String status) {
        Connection connection = DatabaseConnection.getConnection();
        if (connection == null) {
            System.out.println("No database connection. Reservation cannot be saved.");
            return;
        }

        String sql = "INSERT INTO reservations (car_id, client_id, dateTimeReserve, dateTimeDrop, status) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, carId);
            preparedStatement.setInt(2, clientId);
            preparedStatement.setObject(3, dateTimeReserve);
            preparedStatement.setObject(4, dateTimeDrop);
            preparedStatement.setString(5, status);

            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Reservation saved successfully!");
            }
        } catch (SQLException e) {
            System.out.println("Failed to save reservation.");
            e.printStackTrace();
        }
    }

    // Check if a given date is a weekday (Monday to Friday)
    private static boolean isWeekday(LocalDateTime dateTime) {
        DayOfWeek dayOfWeek = dateTime.getDayOfWeek();
        return dayOfWeek != DayOfWeek.SATURDAY && dayOfWeek != DayOfWeek.SUNDAY;
    }

    // Check if the reservation time is within the allowed hours (08:00 to 20:00)
    private static boolean isWithinAllowedHours(LocalDateTime dateTime) {
        int hour = dateTime.getHour();
        return hour >= START_HOUR && hour < END_HOUR;
    }

    // Check if the reservation is in the restricted buffer zone (1 hour before 08:00 or after 20:00)
    private static boolean isInRestrictedBufferZone(LocalDateTime dateTime) {
        int hour = dateTime.getHour();
        return hour < BUFFER_HOUR_BEFORE || hour >= BUFFER_HOUR_AFTER;
    }

    public static void main(String[] args) {
        // Example reservation (valid reservation)
        LocalDateTime reserveDate = LocalDateTime.of(2024, 10, 14, 10, 0);  // Monday 10:00
        LocalDateTime dropDate = LocalDateTime.of(2024, 10, 16, 18, 0);     // Wednesday 18:00

        if (isReservationValid(reserveDate, dropDate)) {
            saveReservation(1, 1, reserveDate, dropDate, "reserved");  // Save valid reservation
        }
    }
}

import java.sql.Connection;
import java.util.Scanner;

public class CarManagementMenu {

    public static void main(String[] args) {
        Connection connection = DatabaseConnection.getConnection();
        if (connection != null) {
            CarDAO carDAO = new CarDAO(connection);
            ClientDAO clientDAO = new ClientDAO(connection);
            ReservationDAO reservationDAO = new ReservationDAO(connection);
            runMenu(carDAO, clientDAO, reservationDAO);
        }
    }

    private static void runMenu(CarDAO carDAO, ClientDAO clientDAO, ReservationDAO reservationDAO) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n=== Car Management Menu ===");
            System.out.println("1. Add Car");
            System.out.println("2. List All Cars");
            System.out.println("3. Update Car");
            System.out.println("4. Delete Car");
            System.out.println("5. Add Client");
            System.out.println("6. List All Clients");
            System.out.println("7. Delete Client");
            System.out.println("8. Add Reservation");
            System.out.println("9. List All Reservations");
            System.out.println("10. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    carDAO.addCar(scanner);
                    break;
                case 2:
                    carDAO.listCars();
                    break;
                case 3:
                    carDAO.updateCar(scanner);
                    break;
                case 4:
                    carDAO.deleteCar(scanner);
                    break;
                case 5:
                    clientDAO.addClient(scanner);
                    break;
                case 6:
                    clientDAO.listClients();
                    break;
                case 7:
                    clientDAO.deleteClient(scanner);
                    break;
                case 8:
                    reservationDAO.addReservation(scanner, carDAO, clientDAO);
                    break;
                case 9:
                    reservationDAO.listReservations();
                    break;
                case 10:
                    System.out.println("Exiting program.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 10);

        scanner.close();
    }
}

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;

public class DatabaseConnection {

    // MySQL connection URL, username, and password
    private static final String URL = "jdbc:mysql://localhost:3306/car_management_db";
    private static final String USER = "root";  // Replace with your MySQL username
    private static final String PASSWORD = "cata";  // Replace with your MySQL password

    // Establish and return a connection to the database
    public static Connection getConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Database connected successfully!");
        } catch (SQLException e) {
            System.out.println("Failed to connect to the database.");
            e.printStackTrace();
        }
        return connection;
    }
}

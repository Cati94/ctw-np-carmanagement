import java.sql.*;
import java.util.Scanner;

public class ReservationDAO {
    private final Connection connection;

    public ReservationDAO(Connection connection) {
        this.connection = connection;
    }

    // Add a new reservation
    public void addReservation(Scanner scanner, CarDAO carDAO, ClientDAO clientDAO) {
        try {
            carDAO.listCars();  // Show available cars
            System.out.print("Enter car ID to reserve: ");
            int carId = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            clientDAO.listClients();  // Show available clients
            System.out.print("Enter client ID: ");
            int clientId = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter reservation date/time (YYYY-MM-DD HH:MM:SS): ");
            String dateTimeReserve = scanner.nextLine();

            System.out.print("Enter drop-off date/time (YYYY-MM-DD HH:MM:SS): ");
            String dateTimeDrop = scanner.nextLine();

            System.out.print("Enter reservation status (e.g., 'reserved', 'completed'): ");
            String status = scanner.nextLine();

            String sql = "INSERT INTO reservations (car_id, client_id, dateTimeReserve, dateTimeDrop, status) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, carId);
            statement.setInt(2, clientId);
            statement.setString(3, dateTimeReserve);
            statement.setString(4, dateTimeDrop);
            statement.setString(5, status);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Reservation created successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // List all reservations
    public void listReservations() {
        try {
            String sql = "SELECT r.id, c.brand, c.model, cl.name, r.dateTimeReserve, r.dateTimeDrop, r.status FROM reservations r " +
                    "JOIN cars c ON r.car_id = c.id " +
                    "JOIN clients cl ON r.client_id = cl.id";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            System.out.println("\n=== List of Reservations ===");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String carBrand = resultSet.getString("brand");
                String carModel = resultSet.getString("model");
                String clientName = resultSet.getString("name");
                String dateTimeReserve = resultSet.getString("dateTimeReserve");
                String dateTimeDrop = resultSet.getString("dateTimeDrop");
                String status = resultSet.getString("status");

                System.out.printf("ID: %d, Car: %s %s, Client: %s, Reserved: %s, Drop-off: %s, Status: %s\n",
                        id, carBrand, carModel, clientName, dateTimeReserve, dateTimeDrop, status);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

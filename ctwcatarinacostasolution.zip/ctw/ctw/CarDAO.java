import java.sql.*;
import java.util.Scanner;

public class CarDAO {
    private final Connection connection;

    public CarDAO(Connection connection) {
        this.connection = connection;
    }

    // 1. Add a new car
    public void addCar(Scanner scanner) {
        try {
            System.out.print("Enter car brand: ");
            String brand = scanner.nextLine();

            System.out.print("Enter car model: ");
            String model = scanner.nextLine();

            System.out.print("Enter engine type: ");
            String engineType = scanner.nextLine();

            System.out.print("Enter autonomy in kms: ");
            int autonomyInKms = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter car color: ");
            String color = scanner.nextLine();

            System.out.print("Enter license plate: ");
            String licensePlate = scanner.nextLine();

            System.out.print("Enter number of seats: ");
            int seats = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            String sql = "INSERT INTO cars (brand, model, engineType, autonomyInKms, color, licensePlate, seats) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, brand);
            statement.setString(2, model);
            statement.setString(3, engineType);
            statement.setInt(4, autonomyInKms);
            statement.setString(5, color);
            statement.setString(6, licensePlate);
            statement.setInt(7, seats);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new car was inserted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 2. List all cars
    public void listCars() {
        try {
            String sql = "SELECT * FROM cars";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            System.out.println("\n=== List of Cars ===");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String brand = resultSet.getString("brand");
                String model = resultSet.getString("model");
                String engineType = resultSet.getString("engineType");
                int autonomyInKms = resultSet.getInt("autonomyInKms");
                String color = resultSet.getString("color");
                String licensePlate = resultSet.getString("licensePlate");
                int seats = resultSet.getInt("seats");

                System.out.printf("ID: %d, Brand: %s, Model: %s, Engine Type: %s, Autonomy: %d kms, Color: %s, License Plate: %s, Seats: %d\n",
                        id, brand, model, engineType, autonomyInKms, color, licensePlate, seats);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 3. Update an existing car
    public void updateCar(Scanner scanner) {
        try {
            System.out.print("Enter car ID to update: ");
            int id = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter new car brand: ");
            String brand = scanner.nextLine();

            System.out.print("Enter new car model: ");
            String model = scanner.nextLine();

            System.out.print("Enter new engine type: ");
            String engineType = scanner.nextLine();

            System.out.print("Enter new autonomy in kms: ");
            int autonomyInKms = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter new car color: ");
            String color = scanner.nextLine();

            System.out.print("Enter new license plate: ");
            String licensePlate = scanner.nextLine();

            System.out.print("Enter new number of seats: ");
            int seats = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            String sql = "UPDATE cars SET brand = ?, model = ?, engineType = ?, autonomyInKms = ?, color = ?, licensePlate = ?, seats = ? WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, brand);
            statement.setString(2, model);
            statement.setString(3, engineType);
            statement.setInt(4, autonomyInKms);
            statement.setString(5, color);
            statement.setString(6, licensePlate);
            statement.setInt(7, seats);
            statement.setInt(8, id);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Car updated successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 4. Delete a car
    public void deleteCar(Scanner scanner) {
        try {
            System.out.print("Enter car ID to delete: ");
            int id = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            String sql = "DELETE FROM cars WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, id);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Car deleted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

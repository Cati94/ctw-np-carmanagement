import java.sql.*;
import java.util.Scanner;

public class ClientDAO {
    private final Connection connection;

    public ClientDAO(Connection connection) {
        this.connection = connection;
    }

    // Add a new client
    public void addClient(Scanner scanner) {
        try {
            System.out.print("Enter client name: ");
            String name = scanner.nextLine();

            System.out.print("Enter client email: ");
            String email = scanner.nextLine();

            System.out.print("Enter client phone: ");
            String phone = scanner.nextLine();

            String sql = "INSERT INTO clients (name, email, phone) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, phone);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new client was added successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // List all clients
    public void listClients() {
        try {
            String sql = "SELECT * FROM clients";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            System.out.println("\n=== List of Clients ===");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                String phone = resultSet.getString("phone");

                System.out.printf("ID: %d, Name: %s, Email: %s, Phone: %s\n", id, name, email, phone);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete a client by ID
    public void deleteClient(Scanner scanner) {
        try {
            System.out.print("Enter client ID to delete: ");
            int id = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            String sql = "DELETE FROM clients WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, id);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Client deleted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
